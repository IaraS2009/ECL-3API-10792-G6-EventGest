using EventGest.Models;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Data;

public static class InicializadorDados
{
    public static async Task Inicializar(AppDbContext contexto)
    {
        if (await contexto.Eventos.AnyAsync())
            return;

        var eventos = new List<Evento>
        {
            new() { Titulo = "Workshop de Programação", Descricao = "Introdução à programação e resolução de pequenos desafios.", Data = DateTime.Today.AddDays(5), Lotacao = 20, Local = "Lisboa" },
            new() { Titulo = "Workshop de Python", Descricao = "Primeiros passos na linguagem Python.", Data = DateTime.Today.AddDays(10), Lotacao = 15, Local = "Sala 2" },
            new() { Titulo = "Introdução às Bases de Dados", Descricao = "Conceitos básicos de bases de dados e SQL.", Data = DateTime.Today.AddDays(15), Lotacao = 25, Local = "Laboratório 1" },
            new() { Titulo = "Criação de Páginas Web", Descricao = "Construção de páginas com HTML e CSS.", Data = DateTime.Today.AddDays(20), Lotacao = 18, Local = "Sala 3" },
            new() { Titulo = "Inteligência Artificial", Descricao = "Conhecer algumas aplicações de inteligência artificial.", Data = DateTime.Today.AddDays(30), Lotacao = 30, Local = "Auditório" }
        };

        var participantes = new List<Participante>
        {
            new() { Nome = "Ana Silva", Email = "ana.silva@email.com", Contacto = "910000001" },
            new() { Nome = "João Costa", Email = "joao.costa@email.com", Contacto = "910000002" },
            new() { Nome = "Maria Santos", Email = "maria.santos@email.com", Contacto = "910000003" },
            new() { Nome = "Pedro Ferreira", Email = "pedro.ferreira@email.com", Contacto = "910000004" },
            new() { Nome = "Inês Almeida", Email = "ines.almeida@email.com", Contacto = "910000005" }
        };

        contexto.Eventos.AddRange(eventos);
        contexto.Participantes.AddRange(participantes);
        await contexto.SaveChangesAsync();

        var inscricoes = new List<Inscricao>
        {
            new() { EventoId = eventos[0].Id, ParticipanteId = participantes[0].Id, DataInscricao = DateTime.Now.AddDays(-2), Estado = "Ativa" },
            new() { EventoId = eventos[0].Id, ParticipanteId = participantes[1].Id, DataInscricao = DateTime.Now.AddDays(-1), Estado = "Ativa" },
            new() { EventoId = eventos[1].Id, ParticipanteId = participantes[2].Id, DataInscricao = DateTime.Now, Estado = "Ativa" },
            new() { EventoId = eventos[2].Id, ParticipanteId = participantes[3].Id, DataInscricao = DateTime.Now, Estado = "Ativa" },
            new() { EventoId = eventos[3].Id, ParticipanteId = participantes[4].Id, DataInscricao = DateTime.Now, Estado = "Ativa" }
        };

        contexto.Inscricoes.AddRange(inscricoes);
        await contexto.SaveChangesAsync();
    }
}
