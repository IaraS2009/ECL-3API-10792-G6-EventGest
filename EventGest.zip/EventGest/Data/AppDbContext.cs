using EventGest.Models;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Evento> Eventos => Set<Evento>();
    public DbSet<Participante> Participantes => Set<Participante>();
    public DbSet<Inscricao> Inscricoes => Set<Inscricao>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Inscricao>()
            .HasIndex(i => new { i.EventoId, i.ParticipanteId })
            .IsUnique();

        modelBuilder.Entity<Inscricao>()
            .HasOne(i => i.Evento)
            .WithMany(e => e.Inscricoes)
            .HasForeignKey(i => i.EventoId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Inscricao>()
            .HasOne(i => i.Participante)
            .WithMany(p => p.Inscricoes)
            .HasForeignKey(i => i.ParticipanteId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
