using System.ComponentModel.DataAnnotations;

namespace EventGest.Models;

public class Evento
{
    public int Id { get; set; }

    [Required(ErrorMessage = "O título é obrigatório.")]
    [StringLength(100, ErrorMessage = "O título não pode ter mais de 100 caracteres.")]
    [Display(Name = "Título")]
    public string Titulo { get; set; } = "";

    [StringLength(500)]
    [Display(Name = "Descrição")]
    public string? Descricao { get; set; }

    [Required(ErrorMessage = "A data é obrigatória.")]
    [DataType(DataType.Date)]
    [Display(Name = "Data")]
    public DateTime Data { get; set; } = DateTime.Today;

    [Range(1, 10000, ErrorMessage = "A lotação tem de ser pelo menos 1.")]
    [Display(Name = "Lotação")]
    public int Lotacao { get; set; }

    [Required(ErrorMessage = "O local é obrigatório.")]
    [StringLength(100)]
    [Display(Name = "Local")]
    public string Local { get; set; } = "";

    public ICollection<Inscricao> Inscricoes { get; set; } = new List<Inscricao>();
}
