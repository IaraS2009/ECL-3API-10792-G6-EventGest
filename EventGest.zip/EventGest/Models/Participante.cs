using System.ComponentModel.DataAnnotations;

namespace EventGest.Models;

public class Participante
{
    public int Id { get; set; }

    [Required(ErrorMessage = "O nome é obrigatório.")]
    [StringLength(100)]
    [Display(Name = "Nome")]
    public string Nome { get; set; } = "";

    [Required(ErrorMessage = "O email é obrigatório.")]
    [EmailAddress(ErrorMessage = "Introduza um email válido.")]
    [StringLength(150)]
    [Display(Name = "Email")]
    public string Email { get; set; } = "";

    [StringLength(20)]
    [Display(Name = "Contacto")]
    public string? Contacto { get; set; }

    public ICollection<Inscricao> Inscricoes { get; set; } = new List<Inscricao>();
}
