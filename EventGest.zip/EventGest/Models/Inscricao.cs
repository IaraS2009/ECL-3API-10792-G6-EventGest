using System.ComponentModel.DataAnnotations;

namespace EventGest.Models;

public class Inscricao
{
    public int Id { get; set; }

    [Display(Name = "Evento")]
    public int EventoId { get; set; }
    public Evento? Evento { get; set; }

    [Display(Name = "Participante")]
    public int ParticipanteId { get; set; }
    public Participante? Participante { get; set; }

    [Display(Name = "Data da inscrição")]
    public DateTime DataInscricao { get; set; } = DateTime.Now;

    [Display(Name = "Estado")]
    public string Estado { get; set; } = "Ativa";
}
