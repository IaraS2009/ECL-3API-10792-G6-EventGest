using EventGest.Data;
using EventGest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Controllers;

public class ParticipantesController : Controller
{
    private readonly AppDbContext _contexto;

    public ParticipantesController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index(string? pesquisa)
    {
        var consulta = _contexto.Participantes.AsQueryable();

        if (!string.IsNullOrWhiteSpace(pesquisa))
        {
            consulta = consulta.Where(p => p.Nome.Contains(pesquisa) || p.Email.Contains(pesquisa));
        }

        ViewBag.Pesquisa = pesquisa;
        return View(await consulta.OrderBy(p => p.Nome).ToListAsync());
    }

    public IActionResult Create() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Participante participante)
    {
        if (!ModelState.IsValid) return View(participante);

        if (await _contexto.Participantes.AnyAsync(p => p.Email == participante.Email))
        {
            ModelState.AddModelError("Email", "Já existe um participante com este email.");
            return View(participante);
        }

        _contexto.Participantes.Add(participante);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Participante registado com sucesso.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();
        var participante = await _contexto.Participantes.FindAsync(id);
        if (participante == null) return NotFound();
        return View(participante);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Participante participante)
    {
        if (id != participante.Id) return NotFound();
        if (!ModelState.IsValid) return View(participante);

        if (await _contexto.Participantes.AnyAsync(p => p.Email == participante.Email && p.Id != id))
        {
            ModelState.AddModelError("Email", "Este email já está associado a outro participante.");
            return View(participante);
        }

        _contexto.Update(participante);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Participante atualizado com sucesso.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();
        var participante = await _contexto.Participantes.FirstOrDefaultAsync(p => p.Id == id);
        if (participante == null) return NotFound();
        return View(participante);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var participante = await _contexto.Participantes.FindAsync(id);
        if (participante == null) return NotFound();

        if (await _contexto.Inscricoes.AnyAsync(i => i.ParticipanteId == id))
        {
            TempData["Erro"] = "Não é possível eliminar este participante porque tem inscrições associadas.";
            return RedirectToAction(nameof(Index));
        }

        _contexto.Participantes.Remove(participante);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Participante eliminado com sucesso.";
        return RedirectToAction(nameof(Index));
    }
}
