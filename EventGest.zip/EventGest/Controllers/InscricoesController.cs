using EventGest.Data;
using EventGest.Models;
using EventGest.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Controllers;

public class InscricoesController : Controller
{
    private readonly AppDbContext _contexto;

    public InscricoesController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index()
    {
        var inscricoes = await _contexto.Inscricoes
            .Include(i => i.Evento)
            .Include(i => i.Participante)
            .OrderByDescending(i => i.DataInscricao)
            .ToListAsync();

        return View(inscricoes);
    }

    public async Task<IActionResult> Create()
    {
        var modelo = new NovaInscricaoViewModel();
        await PreencherListas(modelo);
        return View(modelo);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(NovaInscricaoViewModel modelo)
    {
        if (!ModelState.IsValid)
        {
            await PreencherListas(modelo);
            return View(modelo);
        }

        var evento = await _contexto.Eventos
            .Include(e => e.Inscricoes)
            .FirstOrDefaultAsync(e => e.Id == modelo.EventoId);

        var participante = await _contexto.Participantes.FindAsync(modelo.ParticipanteId);

        if (evento == null || participante == null)
        {
            ModelState.AddModelError("", "O evento ou participante selecionado não existe.");
            await PreencherListas(modelo);
            return View(modelo);
        }

        var inscricaoExistente = await _contexto.Inscricoes
            .FirstOrDefaultAsync(i => i.EventoId == evento.Id && i.ParticipanteId == participante.Id);

        if (inscricaoExistente != null && inscricaoExistente.Estado == "Ativa")
        {
            ModelState.AddModelError("", "Este participante já está inscrito neste evento.");
            await PreencherListas(modelo);
            return View(modelo);
        }

        var inscritos = await _contexto.Inscricoes
            .CountAsync(i => i.EventoId == evento.Id && i.Estado == "Ativa");

        if (inscritos >= evento.Lotacao)
        {
            ModelState.AddModelError("", "Este evento já atingiu a lotação máxima.");
            await PreencherListas(modelo);
            return View(modelo);
        }

        if (evento.Data.Date < DateTime.Today)
        {
            ModelState.AddModelError("", "Não é possível inscrever participantes num evento que já passou.");
            await PreencherListas(modelo);
            return View(modelo);
        }

        if (inscricaoExistente != null)
        {
            inscricaoExistente.Estado = "Ativa";
            inscricaoExistente.DataInscricao = DateTime.Now;
        }
        else
        {
            _contexto.Inscricoes.Add(new Inscricao
            {
                EventoId = evento.Id,
                ParticipanteId = participante.Id,
                DataInscricao = DateTime.Now,
                Estado = "Ativa"
            });
        }

        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Inscrição realizada com sucesso.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancelar(int id)
    {
        var inscricao = await _contexto.Inscricoes.FindAsync(id);
        if (inscricao == null) return NotFound();

        if (inscricao.Estado == "Ativa")
        {
            inscricao.Estado = "Cancelada";
            await _contexto.SaveChangesAsync();
            TempData["Sucesso"] = "Inscrição cancelada.";
        }

        return RedirectToAction(nameof(Index));
    }

    private async Task PreencherListas(NovaInscricaoViewModel modelo)
    {
        modelo.Eventos = await _contexto.Eventos
            .Where(e => e.Data >= DateTime.Today)
            .OrderBy(e => e.Data)
            .Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.Titulo + " - " + e.Data.ToString("dd/MM/yyyy")
            }).ToListAsync();

        modelo.Participantes = await _contexto.Participantes
            .OrderBy(p => p.Nome)
            .Select(p => new SelectListItem
            {
                Value = p.Id.ToString(),
                Text = p.Nome + " (" + p.Email + ")"
            }).ToListAsync();
    }
}
