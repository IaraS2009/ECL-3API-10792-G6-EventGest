using EventGest.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _contexto;

    public HomeController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index()
    {
        ViewBag.TotalEventos = await _contexto.Eventos.CountAsync();
        ViewBag.TotalParticipantes = await _contexto.Participantes.CountAsync();
        ViewBag.TotalInscricoes = await _contexto.Inscricoes.CountAsync(i => i.Estado == "Ativa");

        var proximos = await _contexto.Eventos
            .Include(e => e.Inscricoes)
            .Where(e => e.Data >= DateTime.Today)
            .OrderBy(e => e.Data)
            .Take(5)
            .ToListAsync();

        return View(proximos);
    }

    public IActionResult Erro()
    {
        return View();
    }
}
