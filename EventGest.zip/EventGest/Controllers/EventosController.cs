using EventGest.Data;
using EventGest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventGest.Controllers;

public class EventosController : Controller
{
    private readonly AppDbContext _contexto;

    public EventosController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index()
    {
        var eventos = await _contexto.Eventos
            .Include(e => e.Inscricoes)
            .OrderBy(e => e.Data)
            .ToListAsync();
        return View(eventos);
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var evento = await _contexto.Eventos
            .Include(e => e.Inscricoes.Where(i => i.Estado == "Ativa"))
            .ThenInclude(i => i.Participante)
            .FirstOrDefaultAsync(e => e.Id == id);

        if (evento == null) return NotFound();

        ViewBag.Inscritos = evento.Inscricoes.Count;
        ViewBag.Vagas = evento.Lotacao - evento.Inscricoes.Count;
        ViewBag.Ocupacao = evento.Lotacao == 0 ? 0 :
            Math.Round((double)evento.Inscricoes.Count / evento.Lotacao * 100, 1);

        return View(evento);
    }

    public IActionResult Create() => View(new Evento { Data = DateTime.Today.AddDays(1), Lotacao = 20 });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Evento evento)
    {
        if (!ModelState.IsValid) return View(evento);

        _contexto.Eventos.Add(evento);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Evento criado com sucesso.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();
        var evento = await _contexto.Eventos.FindAsync(id);
        if (evento == null) return NotFound();
        return View(evento);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Evento evento)
    {
        if (id != evento.Id) return NotFound();

        if (!ModelState.IsValid) return View(evento);

        var inscritos = await _contexto.Inscricoes.CountAsync(i => i.EventoId == id && i.Estado == "Ativa");
        if (evento.Lotacao < inscritos)
        {
            ModelState.AddModelError("Lotacao", $"A lotação não pode ser inferior aos {inscritos} participantes inscritos.");
            return View(evento);
        }

        _contexto.Update(evento);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Evento atualizado com sucesso.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();
        var evento = await _contexto.Eventos.FirstOrDefaultAsync(e => e.Id == id);
        if (evento == null) return NotFound();
        return View(evento);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var evento = await _contexto.Eventos.FindAsync(id);
        if (evento == null) return NotFound();

        if (await _contexto.Inscricoes.AnyAsync(i => i.EventoId == id))
        {
            TempData["Erro"] = "Não é possível eliminar este evento porque já tem inscrições associadas.";
            return RedirectToAction(nameof(Index));
        }

        _contexto.Eventos.Remove(evento);
        await _contexto.SaveChangesAsync();
        TempData["Sucesso"] = "Evento eliminado com sucesso.";
        return RedirectToAction(nameof(Index));
    }
}
