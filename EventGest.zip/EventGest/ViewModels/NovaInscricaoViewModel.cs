using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EventGest.ViewModels;

public class NovaInscricaoViewModel
{
    [Required(ErrorMessage = "Escolha um evento.")]
    [Display(Name = "Evento")]
    public int? EventoId { get; set; }

    [Required(ErrorMessage = "Escolha um participante.")]
    [Display(Name = "Participante")]
    public int? ParticipanteId { get; set; }

    public List<SelectListItem> Eventos { get; set; } = new();
    public List<SelectListItem> Participantes { get; set; } = new();
}
