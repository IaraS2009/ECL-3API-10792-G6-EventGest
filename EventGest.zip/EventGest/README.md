# EventGest — Gestão de Eventos e Inscrições

Projeto do Grupo 6 — Módulo 10792, Escola de Comércio de Lisboa.

## Tecnologias
- C#
- ASP.NET Core MVC
- Razor
- Entity Framework Core
- SQLite
- HTML e CSS

## Requisitos
- .NET 8 SDK ou superior compatível com .NET 8
- Visual Studio Code
- Extensão C# (opcional, mas recomendada)

## Como executar no VS Code

1. Extrair a pasta `EventGest`.
2. Abrir a pasta no Visual Studio Code.
3. Abrir o terminal integrado.
4. Executar:

```bash
dotnet restore
dotnet run
```

5. Abrir no navegador o endereço apresentado no terminal (por exemplo, `https://localhost:7xxx` ou `http://localhost:5xxx`).

A base de dados `eventgest.db` é criada automaticamente na primeira execução e são inseridos dados de demonstração.

## Base de dados
Foi utilizada SQLite através do Entity Framework Core. O ficheiro `eventgest.db` é criado na pasta do projeto. Esta opção está prevista no enunciado e não exige instalar ou configurar um servidor de base de dados.

## Funcionalidades
- Criar, consultar, editar e eliminar eventos.
- Registar, consultar, editar e eliminar participantes.
- Realizar e cancelar inscrições.
- Consultar participantes inscritos por evento.
- Impedir inscrições duplicadas.
- Impedir inscrições acima da lotação.
- Consultar vagas disponíveis e taxa de ocupação.
- Validação dos formulários no servidor.
- Proteção antifalsificação nos formulários que alteram dados.

## Dados de demonstração
Na primeira execução são criados 5 eventos, 5 participantes e 5 inscrições de exemplo. Os dados podem ser alterados ou eliminados através do site, respeitando as regras de negócio.

## Nota
Este projeto é uma base funcional para o trabalho. Antes da entrega, o grupo deve testar as funcionalidades, rever o código, personalizar os dados e preparar o relatório técnico e o repositório GitHub.
